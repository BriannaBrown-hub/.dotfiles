# Apex Syntax highlighting
![Example Syntax highlightning](https://github.com/Celador/vscode-apex-extension/raw/master/images/example.png "Apex Syntax Highlighting")

## Deprecation

This extension has been deprecated in favor of [Salesforce DX](https://marketplace.visualstudio.com/items?itemName=salesforce.salesforcedx-vscode)

This extension will no longer receive any updates. You may continue to use this extension for as long as you want.

If you would like to see this project continue, please let me know.
